select last_name, job_id, hire_date from employees 
where last_name ='Matos' or last_name = 'Taylor';