/*Class Name: Demo1
Method: String stringConcat(String,String)  [ returns concatenation of the 2 Strings received ]
Create the above class and method and test it using JUnit.
*/

public class Demo1 {
	String stringConcat(String str1, String str2){
		return str1 + str2;
	}
}
